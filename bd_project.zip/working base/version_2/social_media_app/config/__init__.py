API_KEY = "your_api_key"
API_SECRET_KEY = "your_api_secret_key"
ACCESS_TOKEN = "your_access_token"
ACCESS_TOKEN_SECRET = "your_access_token_secret"

# Post Scheduling Details
POST_SCHEDULES = [
    {"time": "09:00", "content": "Good morning, world! #MorningMotivation"},
    {"time": "12:00", "content": "Lunch break! What's everyone eating today? 🍴 #LunchVibes"},
    {"time": "18:00", "content": "End of the day! What's your highlight today? #DayRecap"},
]

# Interval time between checks (in seconds)
CHECK_INTERVAL = 60