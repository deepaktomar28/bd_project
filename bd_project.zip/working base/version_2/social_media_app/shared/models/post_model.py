from datetime import datetime
from shared.utils.db_utils import db


class Post(db.Model):
    __tablename__ = 'posts'

    post_id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.user_id'), nullable=False)
    content = db.Column(db.Text, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow)

    
    user = db.relationship('User', back_populates='posts')
    scheduled_time = db.Column(db.DateTime, nullable=True)  # For scheduled publishing time
    status = db.Column(db.String(20), default="draft")  # Status of the post (draft, scheduled, published)

    def is_scheduled(self):
        return self.scheduled_time is not None and self.scheduled_time > datetime.utcnow()