from .post_view import router as post_router
from .schedule_view import router as schedule_router

def register_views(app):
    """
    Registers the views (route handlers) into the FastAPI app.
    This function collects all the routers and includes them into the app.
    """
    app.include_router(post_router, prefix="/posts", tags=["posts"])
    app.include_router(schedule_router, prefix="/schedules", tags=["schedules"])
    print("Views registered successfully.")