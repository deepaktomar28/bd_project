from flask import Flask
from app.models.post import db
from app.routes.post_routes import post_routes
from app.config import Config

def create_app():
    app = Flask(_name_)
    app.config.from_object(Config)

    db.init_app(app)

    # Register the routes
    app.register_blueprint(post_routes)

    return app

app = create_app()

if _name_ == "_main_":
    app.run(debug=True)
