from flask import Blueprint, request, jsonify
from post_app.services.post_service import PostService
from datetime import datetime

post_routes = Blueprint('post_routes', __name__)

@post_routes.route('/schedule', methods=['POST'])
def schedule_post():
    content = request.json.get('content')
    scheduled_time_str = request.json.get('scheduled_time')
    scheduled_time = datetime.strptime(scheduled_time_str, '%Y-%m-%d %H:%M:%S')
    
    if not content or not scheduled_time:
        return jsonify({"error": "Missing content or scheduled time"}), 400

    post = PostService.schedule_post(content, scheduled_time)
    return jsonify({"message": "Post scheduled", "post_id": post.id}), 201

@post_routes.route('/posts', methods=['GET'])
def get_scheduled_posts():
    posts = PostService.get_scheduled_posts()
    return jsonify([{"id": post.id, "content": post.content, "scheduled_time": post.scheduled_time} for post in posts])

@post_routes.route('/posts/<int:post_id>', methods=['GET'])
def get_post(post_id):
    post = PostService.get_post_by_id(post_id)
    if post:
        return jsonify({"id": post.id, "content": post.content, "scheduled_time": post.scheduled_time})
    return jsonify({"error": "Post not found"}), 404

@post_routes.route('/posts/<int:post_id>', methods=['DELETE'])
def delete_post(post_id):
    success = PostService.delete_post(post_id)
    if success:
        return jsonify({"message": "Post deleted successfully"})
    return jsonify({"error": "Post not found"}), 404
