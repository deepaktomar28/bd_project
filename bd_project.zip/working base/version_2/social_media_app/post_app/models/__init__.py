from datetime import datetime
from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()

class Post(db.Model):
    _tablename_ = 'posts'
    id = db.Column(db.Integer, primary_key=True)
    content = db.Column(db.String(255), nullable=False)
    scheduled_time = db.Column(db.DateTime, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    def _init_(self, content, scheduled_time):
        self.content = content
        self.scheduled_time = scheduled_time

    def _repr_(self):
        return f"<Post {self.id} - {self.content[:20]}... scheduled at {self.scheduled_time}>"