from apscheduler.schedulers.background import BackgroundScheduler
from datetime import datetime
from post_app.services.post_service import PostService

class SchedulerService:
    def __init__(self):
        self.scheduler = BackgroundScheduler()
        self.scheduler.start()

    def schedule_post_publication(self, post_id, scheduled_time):
        """
        Schedule a job to publish a post at a specified time.
        """
        if scheduled_time > datetime.utcnow():
            self.scheduler.add_job(
                func=PostService.publish_post,
                trigger="date",
                run_date=scheduled_time,
                args=[post_id],
                id=f"publish_post_{post_id}",
                replace_existing=True
            )

    def remove_scheduled_post(self, post_id):
        """
        Remove a scheduled job if the post is rescheduled or deleted.
        """
        job_id = f"publish_post_{post_id}"
        if self.scheduler.get_job(job_id):
            self.scheduler.remove_job(job_id)
