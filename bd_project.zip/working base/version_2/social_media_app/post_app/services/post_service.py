from shared.models.post_model import Post
from shared.utils.db_utils import db
from post_app.services.scheduler_service import SchedulerService
from datetime import datetime

scheduler_service = SchedulerService()

class PostService:
    @staticmethod
    def create_post(user_id, content, scheduled_time=None):
        new_post = Post(user_id=user_id, content=content, status="draft")
        
        if scheduled_time:
            new_post.scheduled_time = scheduled_time
            new_post.status = "scheduled"
            scheduler_service.schedule_post_publication(new_post.post_id, scheduled_time)

        db.session.add(new_post)
        db.session.commit()
        return new_post

    @staticmethod
    def get_post_by_id(post_id):
        return Post.query.filter_by(post_id=post_id).first()

    @staticmethod
    def get_posts_by_user(user_id):
        return Post.query.filter_by(user_id=user_id).all()

    @staticmethod
    def get_all_posts():
        return Post.query.order_by(Post.created_at.desc()).all()

    @staticmethod
    def update_post(post_id, new_content, scheduled_time=None):
        post = Post.query.filter_by(post_id=post_id).first()
        
        if post:
            post.content = new_content
            if scheduled_time:
                post.scheduled_time = scheduled_time
                post.status = "scheduled"
                scheduler_service.schedule_post_publication(post_id, scheduled_time)
            db.session.commit()
        
        return post

    @staticmethod
    def delete_post(post_id):
        post = Post.query.filter_by(post_id=post_id).first()
        if post:
            if post.status == "scheduled":
                scheduler_service.remove_scheduled_post(post_id)
            db.session.delete(post)
            db.session.commit()
        return post
    
    @staticmethod
    def publish_post(post_id):
        post = Post.query.filter_by(post_id=post_id).first()
        if post and post.is_scheduled():
            post.status = "published"
            post.scheduled_time = None
            db.session.commit()
        return post
    
