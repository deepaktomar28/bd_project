from fastapi import APIRouter, BackgroundTasks, HTTPException
from sqlalchemy.orm import Session
from datetime import datetime
from myapp.models import Post  # Assuming the Post model is here
from myapp.tasks import publish_post_task  # Assuming a background task function

# Create the router
router = APIRouter()

# Function to schedule posts (this would check for posts with future publish time)
async def schedule_pending_posts(background_tasks: BackgroundTasks, db: Session):
    """Check if there are posts that need to be scheduled for publishing."""
    # Query posts that need to be scheduled (i.e., posts with a future publish time)
    posts_to_schedule = db.query(Post).filter(Post.publish_at > datetime.now(), Post.is_published == False).all()

    # Add each post to the background tasks to publish them
    for post in posts_to_schedule:
        background_tasks.add_task(publish_post_task, post.id, db)
    
    print(f"Scheduled {len(posts_to_schedule)} posts for publishing.")

# API Endpoint to create a post
@router.post("/posts/")
async def create_post(post: Post, db: Session):
    """Create a post and schedule it for future publishing."""
    db.add(post)
    db.commit()
    db.refresh(post)
    return {"message": "Post created successfully", "post": post}

# API Endpoint to get all posts
@router.get("/posts/")
async def get_posts(db: Session):
    """Retrieve all posts."""
    posts = db.query(Post).all()
    return posts

# API Endpoint to schedule a post manually
@router.post("/schedule/{post_id}/")
async def schedule_post(post_id: int, publish_at: datetime, background_tasks: BackgroundTasks, db: Session):
    """Schedule a specific post to be published at a specific time."""
    post = db.query(Post).filter(Post.id == post_id).first()

    if not post:
        raise HTTPException(status_code=404, detail="Post not found")
    
    post.publish_at = publish_at
    db.commit()

    # Add the scheduling task to the background task queue
    background_tasks.add_task(publish_post_task, post.id, db)

    return {"message": f"Post {post_id} scheduled to be published at {publish_at}"}

# Function to run on app startup to schedule any posts that need to be published
@router.on_event("startup")
async def startup(db: Session, background_tasks: BackgroundTasks):
    """Runs when the FastAPI app starts."""
    print("Starting the app, scheduling posts that need to be published...")
    await schedule_pending_posts(background_tasks, db)
