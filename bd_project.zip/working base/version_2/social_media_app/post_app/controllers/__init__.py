# controllers/_init_.py
from datetime import datetime
from fastapi import BackgroundTasks
from sqlalchemy.ext.asyncio import AsyncSession
from myapp.models import Post, engine
from myapp.tasks import publish_post  # Import the task to publish posts
from sqlalchemy.orm import sessionmaker

# Create an async session factory
SessionLocal = sessionmaker(
    bind=engine,
    class_=AsyncSession,
    expire_on_commit=False,
)

async def schedule_pending_posts(background_tasks: BackgroundTasks):
    """Check if there are posts that need to be scheduled for publishing."""
    # Create a session for querying the database
    async with SessionLocal() as session:
        # Fetch all posts that need to be published
        result = await session.execute(
            select(Post).filter(Post.publish_at > datetime.now(), Post.is_published == False)
        )
        posts_to_schedule = result.scalars().all()

        for post in posts_to_schedule:
            # Schedule the task to publish the post asynchronously in the background
            background_tasks.add_task(publish_post, post.id, session)

        print(f"Scheduled {len(posts_to_schedule)} posts for publishing at startup.")

# Make sure this function is called when the FastAPI app starts